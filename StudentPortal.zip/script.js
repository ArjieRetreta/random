let userDatabase = [
    { name:"arjie", email:"arjie@gmail.com", password:"password123", id:"2026-10492" }
];

let currentUser = null;
let selectedCourses = [];

const availableCourses = [
    { id:"CS101", code:"CS 101", title:"Introduction to Computer Science", units:3, price:300, schedule:"Mon/Wed 09:00 AM - 10:30 AM" },
    { id:"CS102", code:"CS 102", title:"Data Structures & Algorithms", units:4, price:400, schedule:"Tue/Thu 11:00 AM - 01:00 PM" },
    { id:"MATH21", code:"MATH 21", title:"Calculus I", units:4, price:350, schedule:"Mon/Wed/Fri 01:00 PM - 02:00 PM" },
    { id:"ENG11", code:"ENG 11", title:"College Composition", units:3, price:250, schedule:"Tue/Thu 09:30 AM - 11:00 AM" },
    { id:"PHYS11", code:"PHYS 11", title:"University Physics I", units:4, price:420, schedule:"Mon/Wed 03:00 PM - 05:00 PM" }
];

const MAX_UNITS = 21;

document.addEventListener("DOMContentLoaded", () => {
    setupAuthNavigation();
    setupAuthFormHandlers();
    setupPageNavigation();
    setupSettings();

    document.getElementById("submitEnrollment").addEventListener("click", () => {
        alert(`Enrollment Submitted!\n\nTotal Units: ${calculateTotalUnits()}\nEstimated Tuition: $${calculateTotalCost().toFixed(2)}`);
    });

    document.getElementById("printTranscript").addEventListener("click", () => window.print());
});

function setupAuthNavigation() {
    document.getElementById("toRegister").addEventListener("click", e => {
        e.preventDefault();
        document.getElementById("loginForm").classList.add("hidden");
        document.getElementById("registerForm").classList.remove("hidden");
    });

    document.getElementById("toLogin").addEventListener("click", e => {
        e.preventDefault();
        document.getElementById("registerForm").classList.add("hidden");
        document.getElementById("loginForm").classList.remove("hidden");
    });

    document.getElementById("logoutBtn").addEventListener("click", e => {
        e.preventDefault();
        logout();
    });
}

function setupPageNavigation() {
    document.querySelectorAll(".nav-link").forEach(link => {
        link.addEventListener("click", e => {
            e.preventDefault();
            showPage(link.dataset.page);
        });
    });
}

function showPage(pageId) {
    document.querySelectorAll(".portal-page").forEach(page => page.classList.add("hidden"));
    document.getElementById(pageId).classList.remove("hidden");

    document.querySelectorAll(".nav-link").forEach(link => {
        link.classList.toggle("active", link.dataset.page === pageId);
    });
}

function setupAuthFormHandlers() {
    document.getElementById("loginForm").addEventListener("submit", e => {
        e.preventDefault();

        const email = document.getElementById("loginEmail").value.trim();
        const pass = document.getElementById("loginPassword").value;
        const errDiv = document.getElementById("loginError");

        errDiv.classList.add("hidden");

        const foundUser = userDatabase.find(user => user.email === email && user.password === pass);

        if (foundUser) {
            login(foundUser);
        } else {
            errDiv.textContent = "Invalid email address or incorrect password.";
            errDiv.classList.remove("hidden");
        }
    });

    document.getElementById("registerForm").addEventListener("submit", e => {
        e.preventDefault();

        const name = document.getElementById("regName").value.trim();
        const email = document.getElementById("regEmail").value.trim();
        const pass = document.getElementById("regPassword").value;
        const errDiv = document.getElementById("registerError");

        errDiv.classList.add("hidden");

        if (pass.length < 6) {
            errDiv.textContent = "Password must contain at least 6 characters.";
            errDiv.classList.remove("hidden");
            return;
        }

        if (userDatabase.some(user => user.email === email)) {
            errDiv.textContent = "An account with this email already exists.";
            errDiv.classList.remove("hidden");
            return;
        }

        const newUser = {
            name,
            email,
            password:pass,
            id:`2026-${Math.floor(10000 + Math.random() * 90000)}`
        };

        userDatabase.push(newUser);
        alert("Account created successfully!");
        login(newUser);
    });
}

function login(user) {
    currentUser = user;
    selectedCourses = [];

    document.getElementById("userDisplayName").textContent = user.name;
    document.getElementById("userDisplayId").textContent = `ID: ${user.id}`;
    document.getElementById("userAvatar").textContent = user.name.substring(0,2).toUpperCase();

    document.getElementById("transcriptStudentName").textContent = user.name;
    document.getElementById("transcriptStudentId").textContent = `Student ID: ${user.id}`;

    document.getElementById("settingsName").value = user.name;
    document.getElementById("settingsEmail").value = user.email;
    document.getElementById("settingsStudentId").textContent = user.id;

    document.getElementById("authContainer").classList.add("hidden");
    document.getElementById("portalContainer").classList.remove("hidden");

    showPage("enrollmentPage");
    renderCatalog();
    updateSummary();
}

function logout() {
    currentUser = null;
    document.getElementById("loginForm").reset();
    document.getElementById("registerForm").reset();
    document.getElementById("portalContainer").classList.add("hidden");
    document.getElementById("authContainer").classList.remove("hidden");
    document.getElementById("loginForm").classList.remove("hidden");
    document.getElementById("registerForm").classList.add("hidden");
}

function renderCatalog() {
    const container = document.getElementById("courseCatalog");
    container.innerHTML = "";

    availableCourses.forEach(course => {
        const isAdded = selectedCourses.some(item => item.id === course.id);
        const wouldExceed = calculateTotalUnits() + course.units > MAX_UNITS;

        const card = document.createElement("div");
        card.className = "course-card";

        card.innerHTML = `
            <div class="course-info">
                <h4>${course.code}: ${course.title}</h4>
                <div class="course-meta">
                    <span>⏳ ${course.units} Units</span>
                    <span>💰 $${course.price}</span>
                    <span>📅 ${course.schedule}</span>
                </div>
            </div>
            <button class="action-btn add-btn"
                onclick="addCourse('${course.id}')"
                ${isAdded || wouldExceed ? "disabled" : ""}>
                ${isAdded ? "Added" : wouldExceed ? "Limit Exceeded" : "Select Subject"}
            </button>
        `;

        container.appendChild(card);
    });
}

function addCourse(courseId) {
    const course = availableCourses.find(c => c.id === courseId);
    if (!course) return;

    if (calculateTotalUnits() + course.units <= MAX_UNITS) {
        selectedCourses.push(course);
        updateSummary();
        renderCatalog();
    }
}

function dropCourse(courseId) {
    selectedCourses = selectedCourses.filter(c => c.id !== courseId);
    updateSummary();
    renderCatalog();
}

function calculateTotalUnits() {
    return selectedCourses.reduce((sum, item) => sum + item.units, 0);
}

function calculateTotalCost() {
    return selectedCourses.reduce((sum, item) => sum + item.price, 0);
}

function updateSummary() {
    const totalUnits = calculateTotalUnits();
    const totalCost = calculateTotalCost();

    document.getElementById("totalUnits").textContent = `${totalUnits} / ${MAX_UNITS} Max`;
    document.getElementById("totalCost").textContent = `$${totalCost.toFixed(2)}`;

    const selectedContainer = document.getElementById("selectedSubjects");
    const emptyMsg = document.getElementById("emptyCartMessage");
    const submitBtn = document.getElementById("submitEnrollment");

    selectedContainer.querySelectorAll(".selected-item").forEach(item => item.remove());

    if (selectedCourses.length === 0) {
        emptyMsg.style.display = "block";
        submitBtn.disabled = true;
    } else {
        emptyMsg.style.display = "none";
        submitBtn.disabled = false;

        selectedCourses.forEach(course => {
            const li = document.createElement("li");
            li.className = "selected-item";
            li.innerHTML = `
                <div>
                    <strong>${course.code}</strong>
                    <div style="font-size:12px;color:var(--text-muted);">${course.units} Units</div>
                </div>
                <button class="drop-btn" onclick="dropCourse('${course.id}')">Drop</button>
            `;
            selectedContainer.appendChild(li);
        });
    }
}

function setupSettings() {
    document.getElementById("saveProfile").addEventListener("click", () => {
        if (!currentUser) return;

        const newName = document.getElementById("settingsName").value.trim();
        const newEmail = document.getElementById("settingsEmail").value.trim();

        if (!newName || !newEmail) {
            alert("Please fill in all fields.");
            return;
        }

        const emailUsed = userDatabase.some(user => user.email === newEmail && user !== currentUser);

        if (emailUsed) {
            alert("That email address is already being used.");
            return;
        }

        currentUser.name = newName;
        currentUser.email = newEmail;

        document.getElementById("userDisplayName").textContent = newName;
        document.getElementById("userAvatar").textContent = newName.substring(0,2).toUpperCase();
        document.getElementById("transcriptStudentName").textContent = newName;

        const message = document.getElementById("settingsMessage");
        message.textContent = "Profile information updated successfully.";
        message.classList.remove("hidden");

        setTimeout(() => message.classList.add("hidden"), 3000);
    });

    document.getElementById("changePassword").addEventListener("click", () => {
        if (!currentUser) return;

        const currentPassword = document.getElementById("currentPassword").value;
        const newPassword = document.getElementById("newPassword").value;
        const confirmPassword = document.getElementById("confirmPassword").value;

        if (currentPassword !== currentUser.password) {
            alert("Current password is incorrect.");
            return;
        }

        if (newPassword.length < 6) {
            alert("New password must contain at least 6 characters.");
            return;
        }

        if (newPassword !== confirmPassword) {
            alert("New passwords do not match.");
            return;
        }

        currentUser.password = newPassword;

        document.getElementById("currentPassword").value = "";
        document.getElementById("newPassword").value = "";
        document.getElementById("confirmPassword").value = "";

        alert("Password changed successfully.");
    });
}
